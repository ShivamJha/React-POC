import React, { Component } from 'react';
 
class Verify extends Component{

    constructor(props){
        super(props);

        this.state={
            phone: this.props.phone,
            otp: ''
        }
    }

    verifyClick(event) {
        var self = this;
        var payload={
                "otp":this.state.otp,
                "phone":this.state.phone
            }
            

        axios.post(apiBaseUrl + 'validateOTP', payload)
                .then(function(response) {

                console.log(response);
                if (response.status === 200) {
                    console.log("Verification successful");

                    var loginscreen = [];
                    loginscreen.push( < Login parentContext = {this} appContext = {self.props.appContext}/>);
                    
                        var loginmessage = "Not Registered yet.Go to registration"; 
                        self.props.parentContext.setState({
                            loginscreen: loginscreen,
                            loginmessage: loginmessage,
                            buttonLabel: "Register",
                            isLogin: false
                        });
                    }
                    else {
                        console.log("Wrong OTP", response.status);
                    }
                })
            .catch(function(error) {
                console.log(error);
            });
    
    }

    render() {
        return (
        <div>
            <AppBar position="static">
               <Toolbar>
                   <IconButton color="inherit" aria-label="Menu">
                       <MenuIcon />
                   </IconButton>
                   <Typography variant="h6" color="inherit">
                       Verification
                   </Typography>
                   <Button color="inherit">Login</Button>
               </Toolbar>
           </AppBar>
           <TextField
               defaultValue = {this.props.phone}
               floatingLabelText="Phone Number"/>
               <br />
           <TextField
               hintText="OTP"
               floatingLabelText="OTP"
               onChange = {(event , newValue) => self.setState({otp:newValue})}/>
               <br/>
           <RaisedButton label="Verify" primary={true} style={style} onClick={(event) => self.verifyClick(event)}/>
           </div>
           );

    }
}


export default Verify;