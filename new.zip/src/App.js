import React, { Component } from 'react';
import './App.css';
import LoginScreen from './Loginscreen.js';
import Dashboard from './Dashboard';

class App extends Component {
  constructor(props){
    super(props);

    var loginPage =[];
    loginPage.push(<LoginScreen />);


    this.state={
      baseComponent:loginPage,
      logged: false
    }
  }

  check() {
    if(!{this.state.logged}){
      this.setState({
        baseComponent:loginPage
      })
    }
    else{
      var dashboard = [];
      dashboard.push(<Dashboard />)
      this.setState({
        baseComponent:dashboard
      })
    }
  }

  render() {
    return (
      <div className="App">
        this.check();
        {this.state.baseComponent}
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500"></link>
      </div>
    );
  }
}

export default App;
